# what and why
Any entity named "chunkloader" (via anvil) will load the chunk it is in and all adjacent chunks (so and area of 3x3 chunks)

this is so minecarts can still travel any distance


# how to use
- anvil
- put any entity (e.g. ChestMinecart) in the anvil
- name it "chunkloader" 
- be happy
- be careful to not make your server lag


# kill all chunkloaders
`/kill @e[name=chunkloader]`